<!DOCTYPE html>
<html>
<head>
	<title></title>
<script src="js/jquery.js" ></script>

<script src="js/popper.min.js"  crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"  crossorigin="anonymous"></script>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/trabalho.css">
<link rel="stylesheet" type="text/css" href="css/animate.mim.css">



</head> 


<body>
  <div class="bg-light">
  <div class="container" style="width: 100%;">  

    <nav class="navbar navbar-expand-lg navbar-light bg-light ">

      <img src="img/logo_ifc.png" width="30" height="30" alt="">

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto ">
          
          <li class="nav-item">
            <a class="nav-link" href="index.php">Início</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="##">Exemplo</a>
          </li>
                    <li class="nav-item" >
                        <a class="nav-link" href="##">Exemplo</a>
                    </li>
                    <li class="nav-item" >
                        <a class="nav-link" href="##">Exemplo</a>
                    </li>

        </ul>

        <form method="get" action="busca.php" class="form-inline my-2 my-lg-0">
  
          <input class="form-control mr-sm-2" type="text" name="campo_busca">
          <input class="btn btn-outline-dark my-2 my-sm-0" type="submit" name="buscar">
        </form>

       <a href="view/usuario_cadastro.php"> <button type="button" class="btn btn-outline-dark">Cadastro</button></a>


      </div>
    </nav>
  </div>
</div>
</body>
