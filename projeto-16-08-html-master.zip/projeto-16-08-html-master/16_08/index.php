
</body>
</html>

  <?php
   include('cabecalho.php');
  ?>



    <style type="text/css">

  .cards_home{
    margin-top: 5%;
   width: 100%;

  }
      
  .card_home1{
    width: 20%;
    float: left;
   margin-left: 13%;
  }
  .card_home2{
    width: 20%;
    float: left;
    margin-left: 7%;
  }
  .card_home3{
    width: 20%;
    float: left;
  margin-left: 7%;
  }
  

      <style>
  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .hero-image {
    background-image: url("./img/fundo_home.jpg");
    
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
  
    padding: 27em;
  }

  </style>
  </head>
  <body>

  <div class="hero-image">
    <div class="hero-text">
  <center>
           <h1 class="animated fadeInLeftBig tituloIndex">Controle de acesso IFC</h1>
             <button type="button" class="btn btn-outline-dark my-2 my-sm-">Cadastre-se</button>
                   <button type="button" class="btn btn-outline-dark my-2 my-sm-">Entrar</button>
                 
    </div>
  </div>

<center><section class="cards_home">
     <div class="card_home1" >
    <img src="./img/primeiro_card.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <p class="card-text"> Nosso sistema visa trazer maior segurança à toda instituição.</p>
    </div>
  </div>

   <div class="card_home2">
    <img src="./img/primeiro_card.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <p class="card-text">aqui vamos falar os beneficios do nosso sistema.</p>
    </div>
  </div>
  <div class="card_home3">
    <img src="./img/primeiro_card.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <p class="card-text">aqui vamos falar os beneficios do nosso sistema.</p>
    </div>
  </div>
  </section>

<!-- 1. Maior segurança à instituição e aos alunos;
2. Maior controle da instituição e pais dos alunos (menores de idade);
3. Maior agilidade na comunicação entre nupe e os pais ;
!-->

                
    <div>
</center> 




  </body>
  </html>

